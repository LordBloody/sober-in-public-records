import { useState } from "react";

export default function LabelSite() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <div className={darkMode ? "bg-neutral-900 text-white" : "bg-gray-50 text-black"}>
      <div className="p-6 max-w-5xl mx-auto">
        <header className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Sober in Public Records</h1>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="border px-3 py-1 rounded"
          >
            Toggle {darkMode ? "Light" : "Dark"} Mode
          </button>
        </header>

        <section className="my-8">
          <h2 className="text-xl font-semibold mb-2">Our Artists</h2>
          <p>Currently featuring: Bloody</p>
        </section>

        <section className="my-8">
          <h2 className="text-xl font-semibold mb-2">Releases</h2>
          <p>List your label's projects or link to streaming platforms here.</p>
        </section>

        <section className="my-8">
          <h2 className="text-xl font-semibold mb-2">Contact / Demo Submission</h2>
          <p>Email: soberinpublic@example.com</p>
        </section>
      </div>
    </div>
  );
}